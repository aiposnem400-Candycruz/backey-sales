// Fullscreen Overlay Logic
const overlay = document.getElementById('overlay');
const overlayImg = document.getElementById('overlay-img');
const products = document.querySelectorAll('.product img');

products.forEach(img => {
  img.addEventListener('click', () => {
    overlayImg.src = img.src;
    overlay.classList.add('active');
  });
});

overlay.addEventListener('click', () => {
  overlay.classList.remove('active');
});